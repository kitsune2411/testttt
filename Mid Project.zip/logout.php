<?php
include_once "DB.php";

$db = new DB;

$db->doLogout();
